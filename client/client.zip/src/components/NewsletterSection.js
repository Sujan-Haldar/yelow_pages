function NewsletterSection() {
    return ( 
        <section className="newsletter">
            <form action="">
                <h3>subscribe for latest updates</h3>
                <input type="email" name="" placeholder="enter your email" id="" className="box"/>
                <input type="submit" value="subscribe" className="btn"/>
            </form>

        </section>
     );
}

export default NewsletterSection;